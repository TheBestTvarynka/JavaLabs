
install_dir=$1

echo "Start installing..."

if [ ! -d "$install_dir" ]; then
	echo "Creating program directory..."
	mkdir $install_dir
fi

echo "Creatin log dir..."
mkdir $install_dir/logs
touch $install_dir/logs/log.out

echo "Creatin datafiles dir..."
mkdir $install_dir/datafiles
touch $install_dir/datafiles/saved.json

echo "Copying  binary files..."
mkdir $install_dir/bin
cp CourseWork-1.0-jar-with-dependencies.jar $install_dir/bin/

echo "Creating runnable script..."
cp run.sh $install_dir/
chmod +x $install_dir/run.sh

echo "Done! Program is installed in $install_dir successfully"



java -jar bin/CourseWork-1.0-jar-with-dependencies.jar
